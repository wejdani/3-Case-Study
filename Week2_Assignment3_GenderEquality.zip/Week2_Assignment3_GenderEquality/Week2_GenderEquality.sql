
####### first bullet point #######
-- Number of male and female employees in the company.-- 
SELECT 	gender , count(gender)	 
from employees
group by gender;

####### second bullet point #######
-- first we need to find out the last hiring date in the database. 
select * from employees
order by hire_date DESC;

-- the percentage of males and females in the organization-- 

select 
Round(avg(gender = 'M'),2) as M_ration, 
Round(avg(gender = 'F'),2)as F_ration 
from employees
where hire_date >= '1995-1-28';

####### third bullet point #######
 -- list  of the departments that have the highest gaps butween the percentage of males and females in a descending order.

select dept_emp.dept_no, departments.dept_name , 
ROUND(avg(gender = 'M'),2) as M_ration, 
ROUND(avg(gender = 'F'),2)as F_ration 
from  employees
JOIN dept_emp ON employees.emp_no=dept_emp.emp_no
JOIN departments on departments.dept_no = dept_emp.dept_no
where hire_date >= '1995-1-28'
group by dept_no
order by M_ration DESC; 

####### fourth bullet point #######
-- If the ratio is not 1:1,then design a 5-yearplan to resolve this difference when hiring 
-- new employeesto fillnew positions.Clearly state the number of employees we need to hire in each year
-- solved using excel 

-- numbers of males and females in each department.

SELECT dept_emp.dept_no, departments.dept_name ,
count( case when gender='M' then 1 end) as male,
count( case when gender='F' then 1 end) as female
from  ((dept_emp  
join employees  ON employees.emp_no = dept_emp.emp_no)
join departments ON departments.dept_no = dept_emp.dept_no)
where hire_date >= '1995-1-28' 
group by dept_no 
order by dept_no;

####### fiveth bullet point #######
 
-- the average salary for males and females is equal.

select dept_emp.dept_no , departments.dept_name,   
round( avg(case when gender='M' then salary end),2) as M_average_salary,
round( avg(case when gender='F' then salary end),2) as F_average_salary
from  employees
JOIN dept_emp ON employees.emp_no=dept_emp.emp_no
JOIN salaries ON employees.emp_no = salaries.emp_no
JOIN departments ON departments.dept_no = dept_emp.dept_no
where hire_date >= '1995-1-28' 
group by dept_no
order by dept_no; 

