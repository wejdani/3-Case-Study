#########################################################################
-- Bullet Point 1 --
# If the average salary for males and females are not equal, then offer a higher bonus to
# compensate for this circumstance.
select round( avg(case when gender='M' then salary end),2) as M_average_salary,
	   round( avg(case when gender='F' then salary end),2) as F_average_salary
from  employees
JOIN salaries ON employees.emp_no = salaries.emp_no ;

#########################################################################
-- Bullet Point 2 --
#this query checks if anyone has years of service between 7 to 9 years 
select e.emp_no, e.first_name, e.last_name, e.hire_date, round(avg(s.salary)) avg_salary, round(avg(s.salary)*0.05) salary_raise, 
round(datediff('2000-12-31', d.from_date)/365.25,0) AS years_serv from employees e 
join dept_emp d on e.emp_no = d.emp_no
join salaries s on e.emp_no = s.emp_no
where round(datediff('2000-12-31', d.from_date)/365.25,0) >=7 AND round(datediff('2000-12-31', d.from_date)/365.25,0) <=9 
group by e.emp_no
order by e.emp_no;

#this query checks if anyone has years of service between 10 and 15 years
select e.emp_no, e.first_name, e.last_name, e.hire_date, round(avg(s.salary)) avg_salary, round(avg(s.salary)*0.05) salary_raise, 
round(datediff('2000-12-31', d.from_date)/365.25,0) AS years_serv from employees e 
join dept_emp d on e.emp_no = d.emp_no
join salaries s on e.emp_no = s.emp_no
where round(datediff('2000-12-31', d.from_date)/365.25,0) >=10 AND round(datediff('2000-12-31', d.from_date)/365.25,0) <=15
group by e.emp_no
order by e.emp_no;

##########################################################################################################################################################
-- Bullet Point 3 --
# this one returns all the people whose contracts expire 1 year before 2001 
select e.emp_no, first_name, last_name, min(e.hire_date), max(s.to_date), max(salary) as max_salary 
from  employees e
JOIN salaries s ON e.emp_no = s.emp_no
where s.to_date <= '2001-01-02'
group by e.emp_no
order by min(e.hire_date);

